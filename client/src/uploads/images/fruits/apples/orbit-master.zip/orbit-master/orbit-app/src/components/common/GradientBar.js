import React from 'react';

const GradientBar = () => <div className="bg-gradient h-1"></div>;

export default GradientBar;
