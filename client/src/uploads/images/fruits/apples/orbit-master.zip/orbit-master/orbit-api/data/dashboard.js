module.exports = {
  salesVolume: 73977,
  newCustomers: 89,
  refunds: 2254,
  graphData: [
    { date: 'Jan 2019', amount: 1902 },
    { date: 'Feb 2019', amount: 893 },
    { date: 'Mar 2019', amount: 1293 },
    { date: 'Apr 2019', amount: 723 },
    { date: 'May 2019', amount: 2341 },
    { date: 'Jun 2019', amount: 2113 },
    { date: 'Jul 2019', amount: 236 },
    { date: 'Aug 2019', amount: 578 },
    { date: 'Sep 2019', amount: 912 },
    { date: 'Oct 2019', amount: 2934 },
    { date: 'Nov 2019', amount: 345 },
    { date: 'Dec 2019', amount: 782 }
  ]
};
